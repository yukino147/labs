#include <stdio.h>
#include <ctime>
#include <iostream>

using namespace std;

void swap(long *A, int i, int j) {
  int buf = A[i];
  A[i] = A[j];
  A[j] = buf;
}

void Sort(long *A, int n) {
  int i, j;
  bool obmen;
  for (i = 0; i < n; i++) {
    obmen = false;
      for (j = 0; j < n - i - 1; j++) {
        if (A[j] > A[j + 1]) {
          swap(A, j, j+1);
          obmen = true;
          }
      }
      if (!obmen) break;
  }
}

int main() {
  long *A, n;
  time_t t0 = 0, t1 = 0;
  cin >> n;
  A = new long[n];

  srand(time(0));
  for (int i = 0; i < n; i++) {
      A[i] = 0 + 21 * (1.0 * rand()) /RAND_MAX;
  }
  /*for (int i = 0; i < n; i++)
        cout << A[i] << " ";
  cout << endl;*/

  t0 = clock();
  Sort(A, n);
  t1 = clock();
  /*for (int i = 0; i < n; i++)
        cout << A[i] << " ";
  cout << endl;*/


  cout << "t = " << 1.0 * (t1 - t0) / CLOCKS_PER_SEC << endl;

  delete[] A;
}
